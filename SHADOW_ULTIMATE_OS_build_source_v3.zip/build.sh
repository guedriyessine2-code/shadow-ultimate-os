#!/usr/bin/env bash
set -euo pipefail
MAX_BYTES=7000000000
MIN_FREE_KB=$((20 * 1024 * 1024))
FREE_KB=$(df -Pk . | awk 'NR==2 {print $4}')
if [[ -z "$FREE_KB" || "$FREE_KB" -lt "$MIN_FREE_KB" ]]; then
  echo "ERROR: At least 20 GB free space is recommended."
  exit 1
fi
if [[ "$EUID" -eq 0 ]]; then SUDO=""; else SUDO="sudo"; fi
$SUDO apt-get update
$SUDO apt-get install -y live-build debootstrap squashfs-tools xorriso
lb clean --purge || true
lb build
ISO_FILE=$(find . -maxdepth 1 -type f -iname '*.iso' -print -quit)
if [[ -z "$ISO_FILE" ]]; then echo "ERROR: No ISO found."; exit 1; fi
ISO_BYTES=$(stat -c '%s' "$ISO_FILE")
echo "ISO: $ISO_FILE ($ISO_BYTES bytes)"
if (( ISO_BYTES > MAX_BYTES )); then echo "ERROR: ISO exceeds 7 GB."; exit 1; fi
echo "ISO is within the 7 GB size limit."
